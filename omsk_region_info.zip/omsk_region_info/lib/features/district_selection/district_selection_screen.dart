import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/theme/app_theme.dart';
import '../../core/utils/input_sanitizer.dart';
import '../../models/district_model.dart';
import '../../providers/district_provider.dart';
import '../../widgets/common/empty_state_widget.dart';
import '../../widgets/common/loading_widget.dart';

/// Экран выбора района.
/// Показывается только один раз — при первом запуске приложения.
/// Выбор сохраняется навсегда (см. SelectedDistrictNotifier).
class DistrictSelectionScreen extends ConsumerStatefulWidget {
  /// Когда true — экран открыт из "Настроек" для смены уже выбранного
  /// района: показывается кнопка "Назад", а по нажатию "Продолжить" экран
  /// возвращает результат вызывающему через context.pop(), не переходя
  /// на /home напрямую.
  final bool isChangeMode;

  const DistrictSelectionScreen({super.key, this.isChangeMode = false});

  @override
  ConsumerState<DistrictSelectionScreen> createState() =>
      _DistrictSelectionScreenState();
}

class _DistrictSelectionScreenState extends ConsumerState<DistrictSelectionScreen> {
  final TextEditingController _searchController = TextEditingController();
  String _query = '';
  DistrictModel? _chosen;
  bool _isSaving = false;

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final districtsAsync = ref.watch(districtsListProvider);

    return Scaffold(
      backgroundColor: AppTheme.backgroundWhite,
      appBar: widget.isChangeMode
          ? AppBar(title: const Text('Смена района'))
          : null,
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 16),
              Text('Выберите район', style: Theme.of(context).textTheme.headlineLarge),
              const SizedBox(height: 6),
              Text(
                'Приложение покажет новости и организации только вашего района',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: 20),
              TextField(
                controller: _searchController,
                onChanged: (value) => setState(
                  () => _query = InputSanitizer.sanitizeSearchQuery(value),
                ),
                decoration: const InputDecoration(
                  hintText: 'Найти район...',
                  prefixIcon: Icon(Icons.search_rounded, color: AppTheme.textSecondary),
                ),
              ),
              const SizedBox(height: 16),
              Expanded(
                child: districtsAsync.when(
                  loading: () => const LoadingListWidget(),
                  error: (err, st) => EmptyStateWidget.error(
                    onRetry: () => ref.invalidate(districtsListProvider),
                  ),
                  data: (districts) {
                    final filtered = _query.isEmpty
                        ? districts
                        : districts
                            .where((d) => InputSanitizer.normalizeForSearch(d.name)
                                .contains(InputSanitizer.normalizeForSearch(_query)))
                            .toList();

                    if (filtered.isEmpty) {
                      return const EmptyStateWidget(
                        icon: Icons.search_off_rounded,
                        title: 'Ничего не найдено',
                        subtitle: 'Попробуйте изменить запрос',
                      );
                    }

                    return ListView.separated(
                      itemCount: filtered.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 10),
                      itemBuilder: (context, index) {
                        final district = filtered[index];
                        final isSelected = _chosen?.id == district.id;
                        return _DistrictTile(
                          district: district,
                          isSelected: isSelected,
                          onTap: () => setState(() => _chosen = district),
                        );
                      },
                    );
                  },
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 16),
                child: SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: _chosen == null || _isSaving ? null : _onContinue,
                    child: _isSaving
                        ? const SizedBox(
                            width: 22,
                            height: 22,
                            child: CircularProgressIndicator(
                              color: Colors.white,
                              strokeWidth: 2.4,
                            ),
                          )
                        : const Text('Продолжить'),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _onContinue() async {
    if (_chosen == null) return;
    setState(() => _isSaving = true);

    if (widget.isChangeMode) {
      // Решение о смене района (отписка от старого topic, подписка на новый)
      // принимает вызывающий экран (Настройки) — этот экран лишь возвращает
      // выбор пользователя.
      if (!mounted) return;
      context.pop<DistrictPickResult>((id: _chosen!.id, name: _chosen!.name));
      return;
    }

    await ref
        .read(selectedDistrictProvider.notifier)
        .selectDistrict(_chosen!.id, _chosen!.name);
    if (!mounted) return;
    context.go('/home');
  }
}

class _DistrictTile extends StatelessWidget {
  final DistrictModel district;
  final bool isSelected;
  final VoidCallback onTap;

  const _DistrictTile({
    required this.district,
    required this.isSelected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
        decoration: BoxDecoration(
          color: isSelected ? AppTheme.primaryBlueLight : Colors.white,
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: isSelected ? AppTheme.primaryBlue : AppTheme.divider,
            width: isSelected ? 1.6 : 1,
          ),
        ),
        child: Row(
          children: [
            Icon(
              Icons.location_on_outlined,
              color: isSelected ? AppTheme.primaryBlue : AppTheme.textSecondary,
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Text(
                district.name,
                style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      color: isSelected ? AppTheme.primaryBlue : AppTheme.textPrimary,
                    ),
              ),
            ),
            if (isSelected)
              const Icon(Icons.check_circle_rounded, color: AppTheme.primaryBlue),
          ],
        ),
      ),
    );
  }
}
